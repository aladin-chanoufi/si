import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CompPersonalInfoInf.css";

const CompPersonalInfoInf = () => {
  const navigate = useNavigate();

  const onNextTextClick = useCallback(() => {
    navigate("/comp-financial-info-inf");
  }, [navigate]);

  return (
    <div className="comp-personal-info-inf">
      <div className="comp-personal-info-inf-child" />
      <div className="comp-personal-info-inf-item" />
      <div className="comp-personal-info-inf-inner" />
      <div className="comp-personal-info-inf-child1" />
      <div className="comp-personal-info-inf-child2" />
      <div className="comp-personal-info-inf-child3" />
      <div className="comp-personal-info-inf-child4" />
      <div className="div2">+216 98 562 214</div>
      <div className="comp-personal-info-inf-child5" />
      <div className="tunisia1">Tunisia</div>
      <div className="comp-personal-info-inf-child6" />
      <div className="comp-personal-info-inf-child7" />
      <div className="div3">3000</div>
      <div className="rue-des-oranges1">112 rue des oranges sfax</div>
      <div className="comp-personal-info-inf-child8" />
      <div className="comp-personal-info-inf-child9" />
      <div className="sfax1">Sfax</div>
      <div className="comp-personal-info-inf-child10" />
      <div className="masmoudisarahgmailcom1">Masmoudi.sarah@gmail.com</div>
      <div className="full-name36">
        <div className="full-name37">Phone Number*</div>
      </div>
      <b className="complete-your-profile">Complete your profile</b>
      <div className="email">Email*</div>
      <div className="country-of-residence">Country of residence*</div>
      <div className="postal-adress1">Postal Adress*</div>
      <div className="postal-code1">Postal Code*</div>
      <div className="liens-des-rseaux">Liens des réseaux sociaux*</div>
      <div className="city">City*</div>
      <div className="profile-picture1">Profile Picture</div>
      <div className="please-fill-some">
        Please fill some blanks before continuing to the platform BmyB
      </div>
      <div className="personal-information">
        <ol className="personal-information1">
          <li>Personal Information</li>
        </ol>
      </div>
      <div className="comp-personal-info-inf-child11" />
      <div className="next1" onClick={onNextTextClick}>
        Next
      </div>
      <div className="comp-personal-info-inf-child12" />
      <div className="comp-personal-info-inf-child13" />
      <img className="mask-group-icon22" alt="" src="/mask-group@2x.png" />
      <div className="comp-personal-info-inf-child14" />
      <b className="page-14">Page 1</b>
      <b className="page-24">Page 2</b>
      <b className="page-34">Page 3</b>
      <div className="comp-personal-info-inf-child15" />
      <div className="write-anything8">write anything...</div>
      <div className="comp-personal-info-inf-child16" />
      <b className="send8">SEND</b>
      <img className="send-fill-icon8" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor20">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor21">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor22">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="comp-personal-info-inf-child17" />
      <div className="logo14">Logo</div>
      <img className="farasha-02-1-icon1" alt="" src="/farasha02-1@2x.png" />
    </div>
  );
};

export default CompPersonalInfoInf;
