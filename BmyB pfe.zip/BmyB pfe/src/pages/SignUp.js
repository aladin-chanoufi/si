import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./SignUp.css";

const SignUp = () => {
  const navigate = useNavigate();

  const onLoginTextClick = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  return (
    <div className="sign-up">
      <div className="sign-up-child" />
      <img className="icon" alt="" src="/33-787@2x.png" />
      <div className="ready-to-take-container">
        <p className="ready-to-take">Ready to take your</p>
        <p className="business-to-the-next-level">
          <b className="business">BUSINESS</b>
          <span className="to-the-next"> to the next level?</span>
        </p>
      </div>
      <div className="welcome-to-bmyb">Welcome to BmyB!</div>
      <div className="sign-up-item" />
      <div className="logo2">LOGO</div>
      <div className="sign-up-inner" />
      <div className="full-name">
        <div className="full-name1">Confirm password</div>
      </div>
      <div className="line-div" />
      <div className="sign-up-child1" />
      <div className="sign-up-child2" />
      <div className="sign-up-child3" />
      <div className="sign-up-child4" />
      <div className="full-name2">
        <div className="full-name1">Full name</div>
      </div>
      <div className="full-name4">
        <div className="full-name1">Influencer</div>
      </div>
      <div className="full-name6">
        <div className="full-name1">Business owner</div>
      </div>
      <div className="create-your-account">Create your account</div>
      <div className="sign-up-child5" />
      <div className="sign-up1">Sign Up</div>
      <div className="have-an-account">{`Have an account ? `}</div>
      <div className="login" onClick={onLoginTextClick}>
        Login
      </div>
      <div className="sign-up-child6" />
      <div className="sign-up-child7" />
      <div className="sign-up-child8" />
      <img className="icon1" alt="" src="/3-3787@2x.png" />
      <img className="frame-icon" alt="" src="/frame.svg" />
      <img className="frame-icon1" alt="" src="/frame1.svg" />
      <img className="line-icon" alt="" />
      <div className="full-name8">
        <div className="full-name1">Email</div>
      </div>
      <div className="sign-up-child9" />
      <div className="full-name10">
        <div className="full-name1">Password</div>
      </div>
      <div className="sign-up-child10" />
      <img className="view-hide-icon" alt="" src="/view-hide@2x.png" />
      <img className="view-hide-icon1" alt="" src="/view-hide@2x.png" />
      <div className="i-agree-to-container">
        <span>
          <span>I agree to</span>
          <span className="span1">{` `}</span>
        </span>
        <span className="the-terms">the terms</span>
        <span>
          <span className="span1">{` `}</span>
          <span>and</span>
          <span className="span1">{` `}</span>
        </span>
        <span className="the-terms">conditions</span>
      </div>
      <div className="sign-up-child11" />
      <img className="tiktok-icon" alt="" src="/tiktok@2x.png" />
      <img className="google-icon" alt="" src="/google@2x.png" />
      <img className="fb-icon" alt="" src="/fb@2x.png" />
      <img className="inst-icon" alt="" src="/inst@2x.png" />
      <img
        className="happy-young-man-using-laptop-c-icon"
        alt=""
        src="/happyyoungmanusinglaptopcomputerremovebgpreview-1@2x.png"
      />
    </div>
  );
};

export default SignUp;
