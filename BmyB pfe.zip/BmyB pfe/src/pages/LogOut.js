import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./LogOut.css";

const LogOut = () => {
  const navigate = useNavigate();

  const onConsultText7Click = useCallback(() => {
    navigate("/consult-campaign");
  }, [navigate]);

  const onBellIconClick = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  return (
    <div className="log-out">
      <div className="log-out-child" />
      <div className="log-out-item" />
      <div className="log-out-inner" />
      <div className="log-out-child1" />
      <div className="log-out-child2" />
      <div className="log-out-child3" />
      <div className="log-out-child4" />
      <div className="log-out-child5" />
      <div className="log-out-child6" />
      <b className="page-18">Page 1</b>
      <b className="page-28">Page 2</b>
      <b className="page-38">Page 3</b>
      <div className="log-out-child7" />
      <div className="write-anything12">write anything...</div>
      <div className="log-out-child8" />
      <b className="send12">SEND</b>
      <img className="send-fill-icon11" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor50">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor51">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor52">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="log-out-child9" />
      <div className="logo22">Logo</div>
      <div className="available-campaigns3">Available Campaigns</div>
      <div className="log-out-child10" />
      <div className="search10">Search</div>
      <div className="log-out-child11" />
      <img className="filter-big-icon2" alt="" src="/filter-big.svg" />
      <div className="log-out-child12" />
      <div className="log-out-child13" />
      <div className="log-out-child14" />
      <div className="log-out-child15" />
      <div className="log-out-child16" />
      <div className="log-out-child17" />
      <div className="log-out-child18" />
      <div className="log-out-child19" />
      <div className="log-out-child20" />
      <div className="log-out-child21" />
      <div className="consult20">Consult</div>
      <div className="consult21">Consult</div>
      <div className="make-up-campaign2">Make Up Campaign</div>
      <div className="filter-par2">Filter par</div>
      <div className="headphone-campaign2">Headphone Campaign</div>
      <div className="accessories-campaign2">Accessories Campaign</div>
      <img className="mask-group-icon44" alt="" src="/mask-group@2x.png" />
      <div className="log-out-child22" />
      <div className="lorem-ipsum-dolor53">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor54">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor55">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="log-out-child23" />
      <div className="log-out-child24" />
      <div className="log-out-child25" />
      <div className="consult22">Consult</div>
      <div className="consult23">Consult</div>
      <div className="consult24">Consult</div>
      <div className="log-out-child26" />
      <div className="consult25">Consult</div>
      <div className="log-out-child27" />
      <div className="consult26">Consult</div>
      <div className="log-out-child28" />
      <div className="consult27" onClick={onConsultText7Click}>
        Consult
      </div>
      <div className="consult28">Consult</div>
      <div className="log-out-child29" />
      <div className="consult29">Consult</div>
      <div className="fashion-campaign2">Fashion Campaign</div>
      <div className="black-friday-campaign2">Black Friday Campaign</div>
      <div className="sportswear-campaign2">Sportswear Campaign</div>
      <div className="spiring-sale-campaign2">Spiring Sale Campaign</div>
      <div className="decoration-campaign2">Decoration Campaign</div>
      <div className="shoes-campaign2">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor56">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor57">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor58">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor59">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor60">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor61">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon45" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon46" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon47" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon48" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon49" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon50" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon51" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon52" alt="" src="/mask-group@2x.png" />
      <div className="log-out-child30" />
      <div className="log-out-child31" />
      <div className="log-out-child32" />
      <img className="wishlist-1-12" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-22" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-32" alt="" src="/wishlist-1-1@2x.png" />
      <div className="log-out-child33" />
      <div className="log-out-child34" />
      <div className="log-out-child35" />
      <img className="wishlist-1-42" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-52" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-62" alt="" src="/wishlist-1-1@2x.png" />
      <div className="log-out-child36" />
      <div className="log-out-child37" />
      <div className="log-out-child38" />
      <img className="wishlist-1-72" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-82" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-92" alt="" src="/wishlist-1-1@2x.png" />
      <img
        className="expand-down-light-icon7"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="log-out-child39" />
      <div className="log-out-child40" />
      <div className="logo23">Logo</div>
      <div className="log-out-child41" />
      <div className="search11">Search</div>
      <img className="group-icon10" alt="" src="/group2.svg" />
      <img className="group-icon11" alt="" src="/group2.svg" />
      <img className="mask-group-icon53" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi7">Sarah Masmoudi</div>
      <div className="influenceur6">Influenceur</div>
      <img
        className="bell-icon6"
        alt=""
        src="/bell.svg"
        onClick={onBellIconClick}
      />
      <img className="wishlist-1-106" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon5" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns4">
        <p className="my-campaigns5">My campaigns</p>
        <p className="my-campaigns5">{` `}</p>
      </div>
      <div className="log-out-child42" />
      <img className="home-icon4" alt="" src="/home1.svg" />
      <div className="my-space4">My Space</div>
      <div className="collaborations4" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <img className="partnership-1-icon4" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard7" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile5" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard4">
        <div className="darhboard-child14" />
        <div className="darhboard-child15" />
        <div className="darhboard-child16" />
        <div className="darhboard-child17" />
      </div>
      <img className="user-alt-icon4" alt="" src="/user-alt1.svg" />
      <div className="rectangle-group">
        <div className="group-child25" />
        <img className="setting-line-icon" alt="" src="/setting-line@2x.png" />
        <img className="sign-in-circle-icon" alt="" src="/sign-in-circle.svg" />
        <div className="polygon-group">
          <img className="group-child26" alt="" src="/polygon-1.svg" />
          <div className="group-child27" />
        </div>
        <img className="mask-group-icon54" alt="" src="/mask-group@2x.png" />
        <div className="sarah-masmoudi8">Sarah Masmoudi</div>
        <div className="settings-privacy">{`Settings & Privacy`}</div>
        <div className="log-out1">Log Out</div>
      </div>
      <div className="log-out-child43" />
    </div>
  );
};

export default LogOut;
