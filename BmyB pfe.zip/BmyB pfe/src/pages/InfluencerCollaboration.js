import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./InfluencerCollaboration.css";

const InfluencerCollaboration = () => {
  const navigate = useNavigate();

  const onMaskGroupImageClick = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  const onBellIconClick = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onEllipse3Click = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onWishlist110Click = useCallback(() => {
    navigate("/wish-list");
  }, [navigate]);

  const onMySpaceTextClick = useCallback(() => {
    navigate("/saving");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  return (
    <div className="influencer-collaboration">
      <div className="influencer-collaboration-child" />
      <div className="influencer-collaboration-item" />
      <div className="influencer-collaboration-inner" />
      <div className="influencer-collaboration-child1" />
      <div className="influencer-collaboration-child2" />
      <div className="influencer-collaboration-child3" />
      <div className="influencer-collaboration-child4" />
      <div className="influencer-collaboration-child5" />
      <div className="influencer-collaboration-child6" />
      <b className="page-111">Page 1</b>
      <b className="page-211">Page 2</b>
      <b className="page-311">Page 3</b>
      <div className="influencer-collaboration-child7" />
      <div className="write-anything15">write anything...</div>
      <div className="influencer-collaboration-child8" />
      <b className="send15">SEND</b>
      <img className="send-fill-icon14" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor80">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor81">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor82">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="influencer-collaboration-child9" />
      <div className="logo28">Logo</div>
      <img
        className="expand-down-light-icon10"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="influencer-collaboration-child10" />
      <div className="influencer-collaboration-child11" />
      <div className="logo29">Logo</div>
      <div className="influencer-collaboration-child12" />
      <div className="search15">Search</div>
      <img className="group-icon15" alt="" src="/group2.svg" />
      <img
        className="mask-group-icon67"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImageClick}
      />
      <div className="sarah-masmoudi11">Sarah Masmoudi</div>
      <div className="influenceur9">Influenceur</div>
      <img
        className="bell-icon9"
        alt=""
        src="/bell.svg"
        onClick={onBellIconClick}
      />
      <div
        className="influencer-collaboration-child13"
        onClick={onEllipse3Click}
      />
      <img
        className="wishlist-1-109"
        alt=""
        src="/wishlist-1-10@2x.png"
        onClick={onWishlist110Click}
      />
      <img className="farasha-02-1-icon8" alt="" src="/farasha02-1@2x.png" />
      <div className="influencer-collaboration-child14" />
      <img className="partnership-1-icon7" alt="" src="/partnership-1@2x.png" />
      <img className="home-icon7" alt="" src="/home.svg" />
      <div className="my-space7" onClick={onMySpaceTextClick}>
        My Space
      </div>
      <div className="collaborations7">Collaborations</div>
      <div className="dashboard10" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile8" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard7">
        <div className="darhboard-child26" />
        <div className="darhboard-child27" />
        <div className="darhboard-child28" />
        <div className="darhboard-child29" />
      </div>
      <img className="user-alt-icon7" alt="" src="/user-alt1.svg" />
      <div className="fashion-campaign5">Fashion Campaign</div>
      <img className="mask-group-icon68" alt="" src="/mask-group@2x.png" />
      <div className="spring-sale-campaign">Spring sale Campaign</div>
      <img className="mask-group-icon69" alt="" src="/mask-group@2x.png" />
      <div className="dive-into-discounts">
        Dive into discounts! Explore exclusive offers, limited-time deals, and
        seasonal savings. Elevate your spring sales game and captivate customers
        with unbeatable promotions.
      </div>
      <div className="make-up-campaign4">Make up Campaign</div>
      <div className="accessories-campaign4">Accessories Campaign</div>
      <img className="mask-group-icon70" alt="" src="/mask-group@2x.png" />
      <div className="get-glam-with">
        "Get glam with our makeup campaign! Explore a world of beauty and
        confidence with our curated collection of makeup essentials. From bold
        lipsticks to shimmering eyeshadows, unleash your creativity and express
        your unique style. Elevate your makeup routine and discover your
        signature look today!"
      </div>
      <div className="accessorize-your-style">
        "Accessorize your style! Discover our latest accessories campaign
        featuring trendy pieces to elevate your look. From statement jewelry to
        chic handbags, find the perfect finishing touches for any outfit. Shop
        now and add flair to your wardrobe!"
      </div>
      <div className="influencer-collaboration-child15" />
      <div className="activate">Activate</div>
      <div className="influencer-collaboration-child16" />
      <div className="activate1">Activate</div>
      <div className="influencer-collaboration-child17" />
      <div className="activate2">Activate</div>
      <div className="influencer-collaboration-child18" />
      <div className="activate3">Activate</div>
      <img
        className="influencer-collaboration-child19"
        alt=""
        src="/vector-278.svg"
      />
      <img
        className="influencer-collaboration-child20"
        alt=""
        src="/vector-279.svg"
      />
      <img
        className="influencer-collaboration-child21"
        alt=""
        src="/vector-279.svg"
      />
      <img className="mask-group-icon71" alt="" src="/mask-group@2x.png" />
      <b className="collaborations8">Collaborations</b>
      <img className="separator-icon2" alt="" src="/separator1.svg" />
      <img className="r-2-icon1" alt="" src="/r-2@2x.png" />
    </div>
  );
};

export default InfluencerCollaboration;
