import "./WrongPass.css";

const WrongPass = () => {
  return (
    <div className="wrong-pass">
      <div className="wrong-pass-child" />
      <img className="icon2" alt="" src="/33-787@2x.png" />
      <div className="your-next-collaboration-container">
        <p className="your-next-collaboration">
          <span className="your-next">{`Your next `}</span>
          <b>{`COLLABORATION `}</b>
        </p>
        <p className="adventure-awaits">adventure awaits</p>
      </div>
      <div className="welcome-back">Welcome Back !</div>
      <img className="frame-icon2" alt="" src="/frame2.svg" />
      <img className="frame-icon3" alt="" src="/frame1.svg" />
      <div className="wrong-pass-item" />
      <div className="wrong-pass-inner" />
      <div className="logo3">LOGO</div>
      <div className="wrong-password-please">
        Wrong Password Please try again
      </div>
      <div className="wrong-pass-child1" />
      <div className="wrong-pass-child2" />
      <div className="full-name12">
        <div className="full-name13">Masmoudi.sarra@gmail.com</div>
      </div>
      <div className="wrong-pass-child3" />
      <div className="full-name14">
        <div className="full-name15">Email</div>
      </div>
      <div className="wrong-pass-child3" />
      <div className="wrong-pass-child5" />
      <div className="wrong-pass-child6" />
      <div className="sign-in-to">Sign In to BmyB</div>
      <img className="tiktok-icon1" alt="" src="/tiktok@2x.png" />
      <img className="google-icon1" alt="" src="/google@2x.png" />
      <img className="fb-icon1" alt="" src="/fb@2x.png" />
      <img className="inst-icon1" alt="" src="/inst@2x.png" />
      <div className="full-name16">
        <div className="full-name15">**********</div>
      </div>
      <div className="full-name18">
        <div className="full-name15">Password</div>
      </div>
      <div className="wrong-pass-child7" />
      <img className="view-hide-icon2" alt="" src="/view-hide@2x.png" />
      <div className="full-name20">
        <div className="full-name15">Influencer</div>
      </div>
      <div className="full-name22">
        <div className="full-name15">Business owner</div>
      </div>
      <div className="wrong-pass-child8" />
      <div className="wrong-pass-child9" />
      <div className="wrong-pass-child10" />
      <div className="wrong-pass-child11" />
      <div className="sign-in1">Sign In</div>
      <img
        className="pretty-girl-pink-striped-pants-icon"
        alt=""
        src="/prettygirlpinkstripedpantsposingindoorshotspectaculareuropeanwomanfurcoatfoolingaroundpurplewallremovebgpreview-1@2x.png"
      />
    </div>
  );
};

export default WrongPass;
