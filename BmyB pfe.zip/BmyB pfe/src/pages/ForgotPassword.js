import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ForgotPassword.css";

const ForgotPassword = () => {
  const navigate = useNavigate();

  const onRectangle2Click = useCallback(() => {
    navigate("/rest-link");
  }, [navigate]);

  return (
    <div className="forgot-password">
      <div className="forgot-password-child" />
      <img className="icon4" alt="" src="/33-787@2x.png" />
      <div className="forgot-password-item" />
      <div className="logo5">LOGO</div>
      <div className="forgot-password-inner" />
      <div className="forgot-password1">Forgot password</div>
      <div className="please-select-your">
        Please select your option to send password reset link
      </div>
      <div className="forgot-password-child1" onClick={onRectangle2Click} />
      <div className="the-reset-link">
        The reset link will be sent to your email adress registered
      </div>
      <div className="forgot-password-child2" />
      <div className="message">
        <div className="message-child" />
        <img className="message-item" alt="" src="/vector-3.svg" />
      </div>
      <div className="reset-via-email">Reset via email</div>
      <div className="forgot-password-child3" />
      <img className="phone-icon" alt="" />
      <div className="forgot-password-child4" />
      <div className="reset-via-sms">Reset via SMS</div>
      <div className="the-reset-link1">
        The reset link will be sent to your phone number registered
      </div>
      <img className="telephone-1-icon" alt="" src="/telephone-1@2x.png" />
    </div>
  );
};

export default ForgotPassword;
