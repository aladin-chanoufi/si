import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./PickedAtegories.css";

const PickedAtegories = () => {
  const navigate = useNavigate();

  const onNextTextClick = useCallback(() => {
    navigate("/available-campaigns");
  }, [navigate]);

  const onMaskGroupImage9Click = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  return (
    <div className="picked-ategories">
      <div className="picked-ategories-child" />
      <div className="picked-ategories-item" />
      <div className="picked-ategories-inner" />
      <div className="picked-ategories-child1" />
      <div className="picked-ategories-child2" />
      <div className="picked-ategories-child3" />
      <img className="group-icon2" alt="" src="/group.svg" />
      <div className="search2">Search</div>
      <div className="select-campaign-categories-container1">
        <p className="select-campaign-categories1">{`Select campaign categories that suit you `}</p>
        <p className="select-campaign-categories1">
          to start your next collaboration !
        </p>
      </div>
      <div className="picked-ategories-child4" />
      <div className="titre-de-la-container8">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container9">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container10">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container11">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="picked-ategories-child5" />
      <div className="write-anything4">write anything...</div>
      <div className="picked-ategories-child6" />
      <b className="send4">SEND</b>
      <img className="send-fill-icon4" alt="" src="/send-fill@2x.png" />
      <div className="titre-de-la-container8">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container9">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container10">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="titre-de-la-container11">
        <p className="select-campaign-categories1">Titre de la page</p>
        <p className="select-campaign-categories1">{` `}</p>
      </div>
      <div className="picked-ategories-child5" />
      <div className="write-anything4">write anything...</div>
      <div className="picked-ategories-child6" />
      <b className="send4">SEND</b>
      <img className="send-fill-icon4" alt="" src="/send-fill@2x.png" />
      <div className="picked-ategories-child9" />
      <b className="next" onClick={onNextTextClick}>
        Next
      </b>
      <img
        className="expand-down-double-icon1"
        alt=""
        src="/expand-down-double.svg"
      />
      <img className="mask-group-icon10" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon11" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon12" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon13" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon14" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon15" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon16" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon17" alt="" src="/mask-group@2x.png" />
      <div className="fashion-beauty1">{`Fashion & Beauty`}</div>
      <div className="travel-adventure1">{`Travel & Adventure`}</div>
      <div className="photography-videography1">{`Photography & Videography`}</div>
      <div className="pets-animals1">{`Pets & animals`}</div>
      <div className="home-decoration1">{`Home & decoration`}</div>
      <div className="music-entertainment1">{`Music & entertainment`}</div>
      <div className="technology1">Technology</div>
      <div className="food-gastronomy1">{`Food & Gastronomy`}</div>
      <div className="fitness-sports1">{`Fitness & Sports`}</div>
      <img className="mask-group-icon18" alt="" src="/mask-group@2x.png" />
      <div className="footer1" />
      <b className="page-12">Page 1</b>
      <b className="page-22">Page 2</b>
      <b className="page-32">Page 3</b>
      <div className="picked-ategories-child10" />
      <div className="write-anything6">write anything...</div>
      <div className="picked-ategories-child11" />
      <b className="send6">SEND</b>
      <img className="send-fill-icon6" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor14">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor15">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor16">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="picked-ategories-child12" />
      <div className="logo9">Logo</div>
      <div className="picked-ategories-child13" />
      <div className="picked-ategories-child14" />
      <div className="logo10">Logo</div>
      <div className="picked-ategories-child15" />
      <div className="picked-ategories-child16" />
      <div className="search3">Search</div>
      <img className="group-icon3" alt="" src="/group1.svg" />
      <img
        className="mask-group-icon19"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage9Click}
      />
      <div className="sarah-masmoudi1">Sarah Masmoudi</div>
      <div className="influenceur1">Influenceur</div>
      <img className="bell-icon1" alt="" src="/bell.svg" />
      <img className="wishlist-1-101" alt="" src="/wishlist-1-10@2x.png" />
      <img
        className="expand-down-light-icon1"
        alt=""
        src="/expand-down-light.svg"
      />
    </div>
  );
};

export default PickedAtegories;
