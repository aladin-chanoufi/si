import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./Saving.css";

const Saving = () => {
  const navigate = useNavigate();

  const onMaskGroupImage9Click = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  const onBellIconClick = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onWishlist110Click = useCallback(() => {
    navigate("/wish-list");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  const onEllipse12Click = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  return (
    <div className="saving">
      <div className="saving-child" />
      <div className="saving-item" />
      <div className="saving-inner" />
      <div className="saving-child1" />
      <div className="saving-child2" />
      <div className="saving-child3" />
      <div className="saving-child4" />
      <div className="saving-child5" />
      <div className="saving-child6" />
      <b className="page-19">Page 1</b>
      <b className="page-29">Page 2</b>
      <b className="page-39">Page 3</b>
      <div className="saving-child7" />
      <div className="write-anything13">write anything...</div>
      <div className="saving-child8" />
      <b className="send13">SEND</b>
      <img className="send-fill-icon12" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor62">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor63">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor64">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="saving-child9" />
      <div className="logo24">Logo</div>
      <div className="available-campaigns4">Available Campaigns</div>
      <div className="saving-child10" />
      <div className="search12">Search</div>
      <div className="saving-child11" />
      <img className="filter-big-icon3" alt="" src="/filter-big.svg" />
      <div className="saving-child12" />
      <div className="saving-child13" />
      <div className="saving-child14" />
      <div className="saving-child15" />
      <div className="saving-child16" />
      <div className="saving-child17" />
      <div className="saving-child18" />
      <div className="saving-child19" />
      <div className="saving-child20" />
      <div className="saving-child21" />
      <div className="consult30">Consult</div>
      <div className="consult31">Consult</div>
      <div className="make-up-campaign3">Make Up Campaign</div>
      <div className="filter-par3">Filter par</div>
      <div className="headphone-campaign3">Headphone Campaign</div>
      <div className="accessories-campaign3">Accessories Campaign</div>
      <img className="mask-group-icon55" alt="" src="/mask-group@2x.png" />
      <div className="saving-child22" />
      <div className="lorem-ipsum-dolor65">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor66">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor67">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="saving-child23" />
      <div className="saving-child24" />
      <div className="saving-child25" />
      <div className="consult32">Consult</div>
      <div className="consult33">Consult</div>
      <div className="consult34">Consult</div>
      <div className="saving-child26" />
      <div className="consult35">Consult</div>
      <div className="saving-child27" />
      <div className="consult36">Consult</div>
      <div className="saving-child28" />
      <div className="consult37">Consult</div>
      <div className="consult38">Consult</div>
      <div className="saving-child29" />
      <div className="consult39">Consult</div>
      <div className="fashion-campaign3">Fashion Campaign</div>
      <div className="black-friday-campaign3">Black Friday Campaign</div>
      <div className="sportswear-campaign3">Sportswear Campaign</div>
      <div className="spiring-sale-campaign3">Spiring Sale Campaign</div>
      <div className="decoration-campaign3">Decoration Campaign</div>
      <div className="shoes-campaign3">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor68">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor69">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor70">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor71">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor72">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor73">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon56" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon57" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon58" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon59" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon60" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon61" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon62" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon63" alt="" src="/mask-group@2x.png" />
      <div className="saving-child30" />
      <div className="saving-child31" />
      <div className="saving-child32" />
      <img className="bookmark-4-icon" alt="" src="/bookmark-4@2x.png" />
      <img className="wishlist-1-23" alt="" src="/wishlist-1-1@2x.png" />
      <div className="saving-child33" />
      <div className="saving-child34" />
      <div className="saving-child35" />
      <img className="wishlist-1-43" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-53" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-63" alt="" src="/wishlist-1-1@2x.png" />
      <div className="saving-child36" />
      <div className="saving-child37" />
      <div className="saving-child38" />
      <img className="wishlist-1-73" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-83" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-93" alt="" src="/wishlist-1-1@2x.png" />
      <img
        className="expand-down-light-icon8"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="saving-child39" />
      <div className="saving-child40" />
      <div className="logo25">Logo</div>
      <div className="saving-child41" />
      <div className="search13">Search</div>
      <img className="group-icon12" alt="" src="/group2.svg" />
      <img className="group-icon13" alt="" src="/group2.svg" />
      <img
        className="mask-group-icon64"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage9Click}
      />
      <div className="sarah-masmoudi9">Sarah Masmoudi</div>
      <div className="influenceur7">Influenceur</div>
      <img
        className="bell-icon7"
        alt=""
        src="/bell.svg"
        onClick={onBellIconClick}
      />
      <img
        className="wishlist-1-107"
        alt=""
        src="/wishlist-1-10@2x.png"
        onClick={onWishlist110Click}
      />
      <img className="farasha-02-1-icon6" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns6">
        <p className="my-campaigns7">My campaigns</p>
        <p className="my-campaigns7">{` `}</p>
      </div>
      <div className="saving-child42" />
      <img className="home-icon5" alt="" src="/home1.svg" />
      <div className="my-space5">My Space</div>
      <div className="collaborations5" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <img className="partnership-1-icon5" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard8" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile6" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard5">
        <div className="darhboard-child18" />
        <div className="darhboard-child19" />
        <div className="darhboard-child20" />
        <div className="darhboard-child21" />
      </div>
      <img className="user-alt-icon5" alt="" src="/user-alt1.svg" />
      <div className="saving-child43" onClick={onEllipse12Click} />
      <img className="bookmark-3-icon" alt="" src="/bookmark-4@2x.png" />
    </div>
  );
};

export default Saving;
