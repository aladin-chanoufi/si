import "./ProfileInfluenceur.css";

const ProfileInfluenceur = () => {
  return (
    <div className="profile-influenceur">
      <div className="profile-influenceur-child" />
      <div className="profile-influenceur-item" />
      <div className="profile-influenceur-inner" />
      <img
        className="expand-down-light-icon2"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="profile-influenceur-child1" />
      <div className="profile-influenceur-child2" />
      <div className="logo11">Logo</div>
      <div className="profile-influenceur-child3" />
      <div className="search4">Search</div>
      <img className="group-icon4" alt="" src="/group2.svg" />
      <img className="mask-group-icon20" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi2">Sarah Masmoudi</div>
      <div className="influenceur2">Influenceur</div>
      <img className="bell-icon2" alt="" src="/bell.svg" />
      <img className="wishlist-1-102" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon" alt="" src="/farasha02-1@2x.png" />
      <div className="logo11">Logo</div>
      <div className="profile-influenceur-child4" />
      <div className="profile-influenceur-child5" />
      <div className="profile-influenceur-child6" />
      <div className="save">Save</div>
      <div className="profile-influenceur-child7" />
      <div className="profile-influenceur-child8" />
      <div className="profile-influenceur-child9" />
      <div className="profile-influenceur-child10" />
      <div className="profile-influenceur-child11" />
      <div className="profile-influenceur-child12" />
      <div className="profile-influenceur-child13" />
      <div className="my-profile">My Profile</div>
      <div className="profile-influenceur-child14" />
      <div className="profile-influenceur-child15" />
      <b className="page-13">Page 1</b>
      <b className="page-23">Page 2</b>
      <b className="page-33">Page 3</b>
      <div className="profile-influenceur-child16" />
      <div className="write-anything7">write anything...</div>
      <div className="profile-influenceur-child17" />
      <b className="send7">SEND</b>
      <img className="send-fill-icon7" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor17">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor18">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor19">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="profile-influenceur-child18" />
      <div className="logo13">Logo</div>
      <div className="profile-picture">Profile Picture</div>
      <div className="personal-informations">Personal informations</div>
      <div className="adress">Adress</div>
      <div className="first-name">{`First Name `}</div>
      <div className="email-adress">Email Adress</div>
      <div className="phone-number">Phone Number</div>
      <div className="last-name">{`Last Name `}</div>
      <div className="edit">Edit</div>
      <div className="bio">Bio</div>
      <div className="profile-influenceur-child19" />
      <div className="sarah">Sarah</div>
      <div className="profile-influenceur-child20" />
      <div className="profile-influenceur-child21" />
      <div className="masmoudi">Masmoudi</div>
      <div className="profile-influenceur-child22" />
      <div className="profile-influenceur-child23" />
      <div className="country">Country</div>
      <div className="postal-adress">Postal adress</div>
      <div className="postal-code">Postal code</div>
      <div className="city-of-residence">City of residence</div>
      <div className="profile-influenceur-child24" />
      <div className="tunisia">Tunisia</div>
      <div className="profile-influenceur-child25" />
      <div className="sfax">Sfax</div>
      <a
        className="masmoudisarahgmailcom"
        href="mailto:Masmoudi.sarah@gmail.com"
        target="_blank"
      >
        Masmoudi.sarah@gmail.com
      </a>
      <div className="profile-influenceur-child26" />
      <div className="profile-influenceur-child27" />
      <img className="edit-fill-icon" alt="" src="/edit-fill@2x.png" />
      <div className="profile-influenceur-child28" />
      <div className="edit1">Edit</div>
      <img className="edit-fill-icon1" alt="" src="/edit-fill@2x.png" />
      <div className="profile-influenceur-child29" />
      <div className="financial-informations">Financial informations</div>
      <div className="bank-name">Bank name</div>
      <div className="account-number">Account Number</div>
      <div className="confirm-your-account">Confirm your account number</div>
      <div className="profile-influenceur-child30" />
      <div className="profile-influenceur-child31" />
      <div className="profile-influenceur-child32" />
      <div className="profile-influenceur-child33" />
      <div className="edit2">Edit</div>
      <img className="edit-fill-icon2" alt="" src="/edit-fill@2x.png" />
      <img className="mask-group-icon21" alt="" src="/mask-group@2x.png" />
      <div className="div">+216 98 562 214</div>
      <div className="rue-des-oranges">112 rue des oranges sfax</div>
      <div className="div1">3000</div>
      <div className="sarah-masmoudi3">Sarah Masmoudi</div>
      <div className="profile-influenceur-child34" />
      <img className="home-icon" alt="" src="/home.svg" />
      <div className="my-space">My Space</div>
      <div className="collaborations">Collaborations</div>
      <img className="partnership-1-icon" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard">Dashboard</div>
      <div className="my-profile1">My Profile</div>
      <div className="darhboard">
        <div className="darhboard-child" />
        <div className="darhboard-item" />
        <div className="darhboard-inner" />
        <div className="darhboard-child1" />
      </div>
      <img className="user-alt-icon" alt="" src="/user-alt.svg" />
    </div>
  );
};

export default ProfileInfluenceur;
