import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CompFinancialInfoInf.css";

const CompFinancialInfoInf = () => {
  const navigate = useNavigate();

  const onSaveTextClick = useCallback(() => {
    navigate("/campaign-categories");
  }, [navigate]);

  const onPreviousTextClick = useCallback(() => {
    navigate("/comp-personal-info-inf");
  }, [navigate]);

  return (
    <div className="comp-financial-info-inf">
      <div className="comp-financial-info-inf-child" />
      <div className="comp-financial-info-inf-item" />
      <div className="comp-financial-info-inf-inner" />
      <div className="comp-financial-info-inf-child1" />
      <div className="comp-financial-info-inf-child2" />
      <div className="comp-financial-info-inf-child3" />
      <div className="logo15">Logo</div>
      <div className="comp-financial-info-inf-child4" />
      <div className="comp-financial-info-inf-child5" />
      <div className="comp-financial-info-inf-child6" />
      <div className="comp-financial-info-inf-child7" />
      <div className="bh-banque">BH Banque</div>
      <div className="full-name38">
        <div className="full-name39">Account Number*</div>
      </div>
      <b className="well-done-welcome">Well done, Welcome!</b>
      <div className="bank-name1">Bank Name*</div>
      <div className="confirm-account-number">Confirm Account Number*</div>
      <div className="financial-information">
        <ol className="financial-information1">
          <li>Financial Information</li>
        </ol>
      </div>
      <div className="comp-financial-info-inf-child8" />
      <div className="save1" onClick={onSaveTextClick}>
        Save
      </div>
      <div className="comp-financial-info-inf-child9" />
      <div className="previous" onClick={onPreviousTextClick}>
        Previous
      </div>
      <div className="comp-financial-info-inf-child10" />
      <div className="comp-financial-info-inf-child11" />
      <div className="comp-financial-info-inf-child12" />
      <b className="page-15">Page 1</b>
      <b className="page-25">Page 2</b>
      <b className="page-35">Page 3</b>
      <div className="comp-financial-info-inf-child13" />
      <div className="write-anything9">write anything...</div>
      <div className="comp-financial-info-inf-child14" />
      <b className="send9">SEND</b>
      <div className="lorem-ipsum-dolor23">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor24">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor25">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="comp-financial-info-inf-child15" />
      <div className="logo16">Logo</div>
    </div>
  );
};

export default CompFinancialInfoInf;
