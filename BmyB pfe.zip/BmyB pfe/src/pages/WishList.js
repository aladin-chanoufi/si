import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./WishList.css";

const WishList = () => {
  const navigate = useNavigate();

  const onEllipse12Click = useCallback(() => {
    navigate("/saving");
  }, [navigate]);

  const onDellDuotoneLineIcon1Click = useCallback(() => {
    navigate("/delete-from-wish-list");
  }, [navigate]);

  return (
    <div className="wish-list">
      <div className="wish-list-child" />
      <div className="wish-list-item" />
      <div className="wish-list-inner" />
      <div className="wish-list-child1" />
      <div className="wish-list-child2" />
      <div className="wish-list-child3" />
      <div className="wish-list-child4" />
      <div className="wish-list-child5" />
      <div className="wish-list-child6" />
      <b className="page-112">Page 1</b>
      <b className="page-212">Page 2</b>
      <b className="page-312">Page 3</b>
      <div className="wish-list-child7" />
      <div className="write-anything16">write anything...</div>
      <div className="wish-list-child8" />
      <b className="send16">SEND</b>
      <img className="send-fill-icon15" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor83">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor84">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor85">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="wish-list-child9" />
      <div className="logo30">Logo</div>
      <div className="available-campaigns5">Available Campaigns</div>
      <div className="wish-list-child10" />
      <div className="search16">Search</div>
      <div className="wish-list-child11" />
      <img className="filter-big-icon4" alt="" src="/filter-big1.svg" />
      <div className="wish-list-child12" />
      <div className="wish-list-child13" />
      <div className="wish-list-child14" />
      <div className="wish-list-child15" />
      <div className="wish-list-child16" />
      <div className="wish-list-child17" />
      <div className="wish-list-child18" />
      <div className="wish-list-child19" />
      <div className="wish-list-child20" />
      <div className="wish-list-child21" />
      <div className="consult40">Consult</div>
      <div className="consult41">Consult</div>
      <div className="make-up-campaign5">Make Up Campaign</div>
      <div className="filter-par4">Filter par</div>
      <div className="headphone-campaign4">Headphone Campaign</div>
      <div className="accessories-campaign5">Accessories Campaign</div>
      <img className="mask-group-icon72" alt="" src="/mask-group@2x.png" />
      <div className="wish-list-child22" />
      <div className="lorem-ipsum-dolor86">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor87">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor88">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="wish-list-child23" />
      <div className="wish-list-child24" />
      <div className="wish-list-child25" />
      <div className="consult42">Consult</div>
      <div className="consult43">Consult</div>
      <div className="consult44">Consult</div>
      <div className="wish-list-child26" />
      <div className="consult45">Consult</div>
      <div className="wish-list-child27" />
      <div className="consult46">Consult</div>
      <div className="wish-list-child28" />
      <div className="consult47">Consult</div>
      <div className="consult48">Consult</div>
      <div className="wish-list-child29" />
      <div className="consult49">Consult</div>
      <div className="fashion-campaign6">Fashion Campaign</div>
      <div className="black-friday-campaign4">Black Friday Campaign</div>
      <div className="sportswear-campaign4">Sportswear Campaign</div>
      <div className="spiring-sale-campaign4">Spiring Sale Campaign</div>
      <div className="decoration-campaign4">Decoration Campaign</div>
      <div className="shoes-campaign4">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor89">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor90">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor91">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor92">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor93">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor94">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon73" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon74" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon75" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon76" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon77" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon78" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon79" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon80" alt="" src="/mask-group@2x.png" />
      <div className="wish-list-child30" />
      <div className="wish-list-child31" />
      <div className="wish-list-child32" />
      <img className="wishlist-1-24" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-33" alt="" src="/wishlist-1-2@2x.png" />
      <div className="wish-list-child33" />
      <div className="wish-list-child34" />
      <div className="wish-list-child35" />
      <img className="wishlist-1-44" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-54" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-64" alt="" src="/wishlist-1-2@2x.png" />
      <div className="wish-list-child36" />
      <div className="wish-list-child37" />
      <div className="wish-list-child38" />
      <img className="wishlist-1-74" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-84" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-94" alt="" src="/wishlist-1-2@2x.png" />
      <img
        className="expand-down-light-icon11"
        alt=""
        src="/expand-down-light1.svg"
      />
      <div className="wish-list-child39" />
      <div className="wish-list-child40" />
      <div className="logo31">Logo</div>
      <div className="wish-list-child41" />
      <div className="search17">Search</div>
      <img className="group-icon16" alt="" src="/group3.svg" />
      <img className="group-icon17" alt="" src="/group3.svg" />
      <img className="mask-group-icon81" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi12">Sarah Masmoudi</div>
      <div className="influenceur10">Influenceur</div>
      <img className="bell-icon10" alt="" src="/bell1.svg" />
      <img className="wishlist-1-1010" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon9" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns10">
        <p className="my-campaigns11">My campaigns</p>
        <p className="my-campaigns11">{` `}</p>
      </div>
      <div className="wish-list-child42" />
      <img className="home-icon8" alt="" src="/home2.svg" />
      <div className="my-space8">My Space</div>
      <div className="collaborations9">Collaborations</div>
      <img className="partnership-1-icon8" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard11">Dashboard</div>
      <div className="my-profile9">My Profile</div>
      <div className="darhboard8">
        <div className="darhboard-child30" />
        <div className="darhboard-child31" />
        <div className="darhboard-child32" />
        <div className="darhboard-child33" />
      </div>
      <img className="user-alt-icon8" alt="" src="/user-alt2.svg" />
      <div className="wish-list-child43" />
      <div className="wish-list-child44" />
      <div className="submit">Submit</div>
      <div className="fashion-campaign7">Fashion Campaign</div>
      <img className="mask-group-icon82" alt="" src="/mask-group@2x.png" />
      <div className="wish-list-child45" onClick={onEllipse12Click} />
      <div className="ethereal-elegance-encapsulate1">{`"Ethereal Elegance" encapsulates the essence of timeless beauty and sophistication, transporting the audience into a world where grace meets modernity. `}</div>
      <img
        className="dell-duotone-line-icon"
        alt=""
        src="/dell-duotone-line.svg"
      />
      <div className="wish-list-child46" />
      <div className="submit1">Submit</div>
      <div className="spring-sale-campaign1">Spring sale Campaign</div>
      <img className="mask-group-icon83" alt="" src="/mask-group@2x.png" />
      <div className="dive-into-discounts1">
        Dive into discounts! Explore exclusive offers, limited-time deals, and
        seasonal savings. Elevate your spring sales game and captivate customers
        with unbeatable promotions.
      </div>
      <img
        className="dell-duotone-line-icon1"
        alt=""
        src="/dell-duotone-line.svg"
        onClick={onDellDuotoneLineIcon1Click}
      />
      <div className="saved-campaigns">Saved Campaigns</div>
    </div>
  );
};

export default WishList;
