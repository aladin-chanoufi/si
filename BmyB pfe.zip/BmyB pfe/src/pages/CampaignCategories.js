import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CampaignCategories.css";

const CampaignCategories = () => {
  const navigate = useNavigate();

  const onMaskGroupImageClick = useCallback(() => {
    navigate("/picked-ategories");
  }, [navigate]);

  const onMaskGroupImage4Click = useCallback(() => {
    navigate("/picked-ategories");
  }, [navigate]);

  const onMaskGroupImage6Click = useCallback(() => {
    navigate("/picked-ategories");
  }, [navigate]);

  const onMaskGroupImage7Click = useCallback(() => {
    navigate("/picked-ategories");
  }, [navigate]);

  const onMaskGroupImage9Click = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  return (
    <div className="campaign-categories">
      <div className="campaign-categories-child" />
      <div className="campaign-categories-item" />
      <img className="group-icon" alt="" src="/group.svg" />
      <div className="search">Search</div>
      <div className="select-campaign-categories-container">
        <p className="select-campaign-categories">{`Select campaign categories that suit you `}</p>
        <p className="select-campaign-categories">
          to start your next collaboration !
        </p>
      </div>
      <div className="campaign-categories-inner" />
      <div className="titre-de-la-container">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container1">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container2">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container3">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="campaign-categories-child1" />
      <div className="write-anything1">write anything...</div>
      <div className="campaign-categories-child2" />
      <b className="send1">SEND</b>
      <img className="send-fill-icon1" alt="" src="/send-fill@2x.png" />
      <div className="titre-de-la-container">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container1">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container2">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="titre-de-la-container3">
        <p className="select-campaign-categories">Titre de la page</p>
        <p className="select-campaign-categories">{` `}</p>
      </div>
      <div className="campaign-categories-child1" />
      <div className="write-anything1">write anything...</div>
      <div className="campaign-categories-child2" />
      <b className="send1">SEND</b>
      <img className="send-fill-icon1" alt="" src="/send-fill@2x.png" />
      <div className="campaign-categories-child5" />
      <img
        className="expand-down-double-icon"
        alt=""
        src="/expand-down-double.svg"
      />
      <img
        className="mask-group-icon"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImageClick}
      />
      <img className="mask-group-icon1" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon2" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon3" alt="" src="/mask-group@2x.png" />
      <img
        className="mask-group-icon4"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage4Click}
      />
      <img className="mask-group-icon5" alt="" src="/mask-group@2x.png" />
      <img
        className="mask-group-icon6"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage6Click}
      />
      <img
        className="mask-group-icon7"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage7Click}
      />
      <div className="fashion-beauty">{`Fashion & Beauty`}</div>
      <div className="travel-adventure">{`Travel & Adventure`}</div>
      <div className="photography-videography">{`Photography & Videography`}</div>
      <div className="pets-animals">{`Pets & animals`}</div>
      <div className="home-decoration">{`Home & decoration`}</div>
      <div className="music-entertainment">{`Music & entertainment`}</div>
      <div className="technology">Technology</div>
      <div className="food-gastronomy">{`Food & Gastronomy`}</div>
      <div className="fitness-sports">{`Fitness & Sports`}</div>
      <img className="mask-group-icon8" alt="" src="/mask-group@2x.png" />
      <div className="footer" />
      <b className="page-11">Page 1</b>
      <b className="page-21">Page 2</b>
      <b className="page-31">Page 3</b>
      <div className="campaign-categories-child6" />
      <div className="write-anything3">write anything...</div>
      <div className="campaign-categories-child7" />
      <b className="send3">SEND</b>
      <img className="send-fill-icon3" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor11">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor12">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor13">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="campaign-categories-child8" />
      <div className="logo7">Logo</div>
      <div className="campaign-categories-child9" />
      <div className="campaign-categories-child10" />
      <div className="logo8">Logo</div>
      <div className="campaign-categories-child11" />
      <div className="campaign-categories-child12" />
      <div className="search1">Search</div>
      <img className="group-icon1" alt="" src="/group1.svg" />
      <img
        className="mask-group-icon9"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage9Click}
      />
      <div className="sarah-masmoudi">Sarah Masmoudi</div>
      <div className="influenceur">Influenceur</div>
      <img className="bell-icon" alt="" src="/bell.svg" />
      <img className="wishlist-1-10" alt="" src="/wishlist-1-10@2x.png" />
      <img
        className="expand-down-light-icon"
        alt=""
        src="/expand-down-light.svg"
      />
    </div>
  );
};

export default CampaignCategories;
