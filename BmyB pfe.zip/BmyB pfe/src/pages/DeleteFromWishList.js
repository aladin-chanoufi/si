import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./DeleteFromWishList.css";

const DeleteFromWishList = () => {
  const navigate = useNavigate();

  const onConsultText10Click = useCallback(() => {
    navigate("/consult-campaign");
  }, [navigate]);

  return (
    <div className="delete-from-wish-list">
      <div className="delete-from-wish-list-child" />
      <div className="delete-from-wish-list-item" />
      <div className="delete-from-wish-list-inner" />
      <div className="delete-from-wish-list-child1" />
      <div className="delete-from-wish-list-child2" />
      <div className="delete-from-wish-list-child3" />
      <div className="delete-from-wish-list-child4" />
      <div className="delete-from-wish-list-child5" />
      <div className="delete-from-wish-list-child6" />
      <b className="page-113">Page 1</b>
      <b className="page-213">Page 2</b>
      <b className="page-313">Page 3</b>
      <div className="delete-from-wish-list-child7" />
      <div className="write-anything17">write anything...</div>
      <div className="delete-from-wish-list-child8" />
      <b className="send17">SEND</b>
      <img className="send-fill-icon16" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor95">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor96">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor97">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="delete-from-wish-list-child9" />
      <div className="logo32">Logo</div>
      <div className="available-campaigns6">Available Campaigns</div>
      <div className="delete-from-wish-list-child10" />
      <div className="search18">Search</div>
      <img className="filter-big-icon5" alt="" src="/filter-big1.svg" />
      <div className="delete-from-wish-list-child11" />
      <div className="delete-from-wish-list-child12" />
      <div className="delete-from-wish-list-child13" />
      <div className="delete-from-wish-list-child14" />
      <div className="delete-from-wish-list-child15" />
      <div className="delete-from-wish-list-child16" />
      <div className="delete-from-wish-list-child17" />
      <div className="delete-from-wish-list-child18" />
      <div className="delete-from-wish-list-child19" />
      <div className="delete-from-wish-list-child20" />
      <div className="consult50">Consult</div>
      <div className="consult51">Consult</div>
      <div className="make-up-campaign6">Make Up Campaign</div>
      <div className="headphone-campaign5">Headphone Campaign</div>
      <div className="accessories-campaign6">Accessories Campaign</div>
      <img className="mask-group-icon84" alt="" src="/mask-group@2x.png" />
      <div className="delete-from-wish-list-child21" />
      <div className="lorem-ipsum-dolor98">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor99">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor100">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="delete-from-wish-list-child22" />
      <div className="delete-from-wish-list-child23" />
      <div className="delete-from-wish-list-child24" />
      <div className="consult52">Consult</div>
      <div className="consult53">Consult</div>
      <div className="consult54">Consult</div>
      <div className="delete-from-wish-list-child25" />
      <div className="consult55">Consult</div>
      <div className="delete-from-wish-list-child26" />
      <div className="consult56">Consult</div>
      <div className="delete-from-wish-list-child27" />
      <div className="consult57">Consult</div>
      <div className="consult58">Consult</div>
      <div className="delete-from-wish-list-child28" />
      <div className="consult59">Consult</div>
      <div className="fashion-campaign8">Fashion Campaign</div>
      <div className="black-friday-campaign5">Black Friday Campaign</div>
      <div className="sportswear-campaign5">Sportswear Campaign</div>
      <div className="spiring-sale-campaign5">Spiring Sale Campaign</div>
      <div className="decoration-campaign5">Decoration Campaign</div>
      <div className="shoes-campaign5">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor101">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor102">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor103">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor104">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor105">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor106">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon85" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon86" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon87" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon88" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon89" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon90" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon91" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon92" alt="" src="/mask-group@2x.png" />
      <div className="delete-from-wish-list-child29" />
      <div className="delete-from-wish-list-child30" />
      <div className="delete-from-wish-list-child31" />
      <img className="wishlist-1-25" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-34" alt="" src="/wishlist-1-2@2x.png" />
      <div className="delete-from-wish-list-child32" />
      <div className="delete-from-wish-list-child33" />
      <div className="delete-from-wish-list-child34" />
      <img className="wishlist-1-45" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-55" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-65" alt="" src="/wishlist-1-2@2x.png" />
      <div className="delete-from-wish-list-child35" />
      <div className="delete-from-wish-list-child36" />
      <div className="delete-from-wish-list-child37" />
      <img className="wishlist-1-75" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-85" alt="" src="/wishlist-1-2@2x.png" />
      <img className="wishlist-1-95" alt="" src="/wishlist-1-2@2x.png" />
      <img
        className="expand-down-light-icon12"
        alt=""
        src="/expand-down-light1.svg"
      />
      <div className="delete-from-wish-list-child38" />
      <div className="delete-from-wish-list-child39" />
      <div className="logo33">Logo</div>
      <div className="delete-from-wish-list-child40" />
      <div className="search19">Search</div>
      <img className="group-icon18" alt="" src="/group3.svg" />
      <img className="group-icon19" alt="" src="/group3.svg" />
      <img className="mask-group-icon93" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi13">Sarah Masmoudi</div>
      <div className="influenceur11">Influenceur</div>
      <img className="bell-icon11" alt="" src="/bell1.svg" />
      <img className="wishlist-1-1011" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon10" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns12">
        <p className="my-campaigns13">My campaigns</p>
        <p className="my-campaigns13">{` `}</p>
      </div>
      <div className="delete-from-wish-list-child41" />
      <img className="home-icon9" alt="" src="/home2.svg" />
      <div className="my-space9">My Space</div>
      <div className="collaborations10">Collaborations</div>
      <img className="partnership-1-icon9" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard12">Dashboard</div>
      <div className="my-profile10">My Profile</div>
      <div className="darhboard9">
        <div className="darhboard-child34" />
        <div className="darhboard-child35" />
        <div className="darhboard-child36" />
        <div className="darhboard-child37" />
      </div>
      <img className="user-alt-icon9" alt="" src="/user-alt2.svg" />
      <div className="delete-from-wish-list-child42" />
      <div className="delete-from-wish-list-child43" />
      <div className="consult60" onClick={onConsultText10Click}>
        Consult
      </div>
      <div className="fashion-campaign9">Fashion Campaign</div>
      <img className="mask-group-icon94" alt="" src="/mask-group@2x.png" />
      <div className="delete-from-wish-list-child44" />
      <img
        className="expand-right-light-icon"
        alt=""
        src="/expand-right-light.svg"
      />
      <div className="ethereal-elegance-encapsulate2">{`"Ethereal Elegance" encapsulates the essence of timeless beauty and sophistication, transporting the audience into a world where grace meets modernity. `}</div>
      <img
        className="dell-duotone-line-icon2"
        alt=""
        src="/dell-duotone-line.svg"
      />
      <div className="saved-campaigns1">Saved Campaigns</div>
    </div>
  );
};

export default DeleteFromWishList;
