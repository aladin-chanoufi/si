import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./Notification1.css";

const Notification1 = () => {
  const navigate = useNavigate();

  const onConsultText7Click = useCallback(() => {
    navigate("/consult-campaign");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  return (
    <div className="notification">
      <div className="notification-child" />
      <div className="notification-item" />
      <div className="notification-inner" />
      <div className="notification-child1" />
      <div className="notification-child2" />
      <div className="notification-child3" />
      <div className="notification-child4" />
      <div className="notification-child5" />
      <div className="notification-child6" />
      <b className="page-17">Page 1</b>
      <b className="page-27">Page 2</b>
      <b className="page-37">Page 3</b>
      <div className="notification-child7" />
      <div className="write-anything11">write anything...</div>
      <div className="notification-child8" />
      <b className="send11">SEND</b>
      <img className="send-fill-icon10" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor38">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor39">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor40">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="notification-child9" />
      <div className="logo20">Logo</div>
      <div className="available-campaigns2">Available Campaigns</div>
      <div className="notification-child10" />
      <div className="search8">Search</div>
      <div className="notification-child11" />
      <img className="filter-big-icon1" alt="" src="/filter-big.svg" />
      <div className="notification-child12" />
      <div className="notification-child13" />
      <div className="notification-child14" />
      <div className="notification-child15" />
      <div className="notification-child16" />
      <div className="notification-child17" />
      <div className="notification-child18" />
      <div className="notification-child19" />
      <div className="notification-child20" />
      <div className="notification-child21" />
      <div className="consult10">Consult</div>
      <div className="consult11">Consult</div>
      <div className="make-up-campaign1">Make Up Campaign</div>
      <div className="filter-par1">Filter par</div>
      <div className="headphone-campaign1">Headphone Campaign</div>
      <div className="accessories-campaign1">Accessories Campaign</div>
      <img className="mask-group-icon34" alt="" src="/mask-group@2x.png" />
      <div className="notification-child22" />
      <div className="lorem-ipsum-dolor41">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor42">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor43">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="notification-child23" />
      <div className="notification-child24" />
      <div className="notification-child25" />
      <div className="consult12">Consult</div>
      <div className="consult13">Consult</div>
      <div className="consult14">Consult</div>
      <div className="notification-child26" />
      <div className="consult15">Consult</div>
      <div className="notification-child27" />
      <div className="consult16">Consult</div>
      <div className="notification-child28" />
      <div className="consult17" onClick={onConsultText7Click}>
        Consult
      </div>
      <div className="consult18">Consult</div>
      <div className="notification-child29" />
      <div className="consult19">Consult</div>
      <div className="fashion-campaign1">Fashion Campaign</div>
      <div className="black-friday-campaign1">Black Friday Campaign</div>
      <div className="sportswear-campaign1">Sportswear Campaign</div>
      <div className="spiring-sale-campaign1">Spiring Sale Campaign</div>
      <div className="decoration-campaign1">Decoration Campaign</div>
      <div className="shoes-campaign1">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor44">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor45">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor46">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor47">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor48">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor49">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon35" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon36" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon37" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon38" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon39" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon40" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon41" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon42" alt="" src="/mask-group@2x.png" />
      <div className="notification-child30" />
      <div className="notification-child31" />
      <div className="notification-child32" />
      <img className="wishlist-1-11" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-21" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-31" alt="" src="/wishlist-1-1@2x.png" />
      <div className="notification-child33" />
      <div className="notification-child34" />
      <div className="notification-child35" />
      <img className="wishlist-1-41" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-51" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-61" alt="" src="/wishlist-1-1@2x.png" />
      <div className="notification-child36" />
      <div className="notification-child37" />
      <div className="notification-child38" />
      <img className="wishlist-1-71" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-81" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-91" alt="" src="/wishlist-1-1@2x.png" />
      <img
        className="expand-down-light-icon6"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="notification-child39" />
      <div className="notification-child40" />
      <div className="logo21">Logo</div>
      <div className="notification-child41" />
      <div className="search9">Search</div>
      <img className="group-icon8" alt="" src="/group2.svg" />
      <img className="group-icon9" alt="" src="/group2.svg" />
      <img className="mask-group-icon43" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi6">Sarah Masmoudi</div>
      <div className="influenceur5">Influenceur</div>
      <img className="bell-icon5" alt="" src="/bell.svg" />
      <img className="wishlist-1-105" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon4" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns2">
        <p className="my-campaigns3">My campaigns</p>
        <p className="my-campaigns3">{` `}</p>
      </div>
      <div className="notification-child42" />
      <img className="home-icon3" alt="" src="/home1.svg" />
      <div className="my-space3">My Space</div>
      <div className="collaborations3" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <img className="partnership-1-icon3" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard6" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile4" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard3">
        <div className="darhboard-child10" />
        <div className="darhboard-child11" />
        <div className="darhboard-child12" />
        <div className="darhboard-child13" />
      </div>
      <img className="user-alt-icon3" alt="" src="/user-alt1.svg" />
      <div className="rectangle-parent">
        <div className="group-child23" />
        <div className="polygon-parent">
          <img className="polygon-icon" alt="" src="/polygon-1.svg" />
          <div className="group-child24" />
        </div>
      </div>
      <div className="notifications">Notifications</div>
      <div className="today">Today</div>
      <div className="new-campaign-alert">
        New Campaign Alert: Exciting opportunities await! Check out the latest
        campaigns available for collaboration.
      </div>
      <div className="achievement-unlocked-youve">
        Achievement Unlocked: You've reached a milestone in your influencer
        journey. Keep up the great work!
      </div>
      <div className="stay-engaged-engage">
        Stay Engaged: Engage with your audience and increase your influence.
        Keep sharing compelling content!
      </div>
      <div className="hour-ago">1 Hour ago</div>
      <div className="hours-ago">6 hours ago</div>
      <div className="hours-ago1">9 hours ago</div>
      <div className="notification-child43" />
    </div>
  );
};

export default Notification1;
