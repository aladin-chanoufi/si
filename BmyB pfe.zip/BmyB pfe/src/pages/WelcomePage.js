import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./WelcomePage.css";

const WelcomePage = () => {
  const navigate = useNavigate();

  const onSignInTextClick = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  return (
    <div className="welcome-page">
      <div className="welcome-page-child" />
      <div className="frame">
        <b className="home">Home</b>
        <div className="services">Services</div>
        <div className="blog">Blog</div>
        <div className="contact-us">Contact Us</div>
        <div className="frame-child" />
        <div className="frame-child" />
        <div className="lorem-ipsum-dolor">{`Lorem ipsum dolor sit amet, consectetuer adipiscing `}</div>
        <div className="frame-inner" />
        <b className="start-now">{`Start Now ! `}</b>
        <b className="unlock-your-potential-container">
          <p className="unlock-your-potential">Unlock Your Potential</p>
        </b>
        <div className="boost-your-business-container">
          <span>
            <b>Boost</b>
          </span>
          <span className="your">
            <span>{` `}</span>
            <span className="your1">Your</span>
            <span className="span">{` `}</span>
          </span>
          <b>Business</b>
        </div>
        <div className="ellipse-div" />
        <div className="logo">Logo</div>
        <div className="rectangle-div" />
        <b className="sign-in" onClick={onSignInTextClick}>
          Sign In
        </b>
        <div className="frame-child1" />
        <img
          className="removebg-preview-1-icon"
          alt=""
          src="/1removebgpreview-1@2x.png"
        />
      </div>
      <div className="frame1">
        <b className="about-us">About Us</b>
        <div className="lorem-ipsum-dolor1">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
          nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat
          volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation
          ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
          Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse
          molestie consequat, vel illum dolore eu feugiat nulla facilisis a
        </div>
        <img
          className="de4b331ef3bce045dfeaee1c00a-icon"
          alt=""
          src="/72268de4b331ef3bce045dfeaee1c00a@2x.png"
        />
        <img
          className="e089005502122858a812b0b6d2b563-icon"
          alt=""
          src="/e089005502122858a812b0b6d2b56300-1@2x.png"
        />
        <img
          className="f36cd003421530e59cc4d352294d8f-icon"
          alt=""
          src="/f36cd003421530e59cc4d352294d8fcc-1@2x.png"
        />
      </div>
      <div className="frame2">
        <div className="frame-child2" />
        <div className="frame-child3" />
        <div className="nous-aidons-les-container">
          <p className="nous-aidons-les">{`   Nous aidons les influenceurs à monitiser `}</p>
          <p className="nous-aidons-les">
            {" "}
            leurs comptes instagram et les infleuceurs
          </p>
          <p className="unlock-your-potential">à développer leurs affaires</p>
        </div>
        <b className="why-choose-us">Why Choose Us?</b>
        <div className="lorem-ipsum-dolor2">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad `}</div>
        <img
          className="cb397a1d835b6216961663ef0b204d-icon"
          alt=""
          src="/cb397a1d835b6216961663ef0b204df3@2x.png"
        />
        <img
          className="efe46193bcdcfad2554d01f73fc79d-icon"
          alt=""
          src="/5efe46193bcdcfad2554d01f73fc79d0@2x.png"
        />
        <img
          className="d43008ec404d37e5d1fd94c082cd04-icon"
          alt=""
          src="/d43008ec404d37e5d1fd94c082cd04b6@2x.png"
        />
        <div className="frame-child4" />
        <div className="frame-child5" />
        <div className="frame-child6" />
        <div className="frame-child7" />
        <b className="credibility">Credibility</b>
        <b className="save-time">Save time</b>
        <div className="frame-child8" />
        <div className="frame-child9" />
        <div className="frame-child10" />
        <div className="frame-child11" />
        <img
          className="a58c59c2aa406a23670be5d73a3de9-icon"
          alt=""
          src="/a58c59c2aa406a23670be5d73a3de925removebgpreview-1@2x.png"
        />
        <img
          className="fffc75d08bb3a5939cb895d4a1f-re-icon"
          alt=""
          src="/33786fffc75d08bb3a5939cb895d4a1fremovebgpreview-1@2x.png"
        />
        <img
          className="a1199dae797f351b8635ee7543b184-icon"
          alt=""
          src="/33a1199dae797f351b8635ee7543b184removebgpreview-1@2x.png"
        />
        <div className="frame-child12" />
        <img
          className="cc4ac8fd409a34742402468d59f7-r-icon"
          alt=""
          src="/3019cc4ac8fd409a34742402468d59f7removebgpreview-1@2x.png"
        />
        <b className="security">Security</b>
        <div className="bmyb-provides-you">
          BmyB provides you the ultimate security
        </div>
        <b className="earn-more-money">Earn More Money</b>
        <div className="you-will-find">
          You will find campaigns in less than 1 minute
        </div>
        <div className="save-money-and">Save money and make more with BmyB</div>
        <b className="real-time-analytic">Real time analytic tool</b>
        <img className="image-7-icon" alt="" src="/image-7@2x.png" />
      </div>
      <div className="frame3">
        <div className="frame-child13" />
        <div className="frame-child14" />
        <div className="frame-child15" />
        <div className="check-our-new-container">
          <span>{`Check our `}</span>
          <span className="new">NEW</span>
          <span> articles</span>
        </div>
        <b className="grow-your-business">Grow your business</b>
        <div className="lorem-ipsum-dolor3">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad `}</div>
        <b className="make-more-money">{`Make more money `}</b>
        <div className="lorem-ipsum-dolor4">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad `}</div>
      </div>
      <div className="frame4">
        <div className="frame-child16" />
        <div className="lorem-ipsum-dolor5">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi `}</div>
        <div className="frame-child17" />
        <b className="read-more">Read more</b>
        <div className="frame-child18" />
        <div className="lorem-ipsum-dolor6">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi `}</div>
        <div className="frame-child19" />
        <b className="read-more1">Read more</b>
        <b className="read-more2">Read more</b>
        <img
          className="f59c9894bb434770e707b6b01d8389-icon"
          alt=""
          src="/f59c9894bb434770e707b6b01d83899b-2@2x.png"
        />
        <div className="frame-child20" />
        <div className="lorem-ipsum-dolor7">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi `}</div>
        <div className="frame-child21" />
        <b className="read-more3">Read more</b>
        <img
          className="fc9de80da08a4e4f57199ccc16228f-icon"
          alt=""
          src="/fc9de80da08a4e4f57199ccc16228f2b@2x.png"
        />
        <img
          className="caa8c429ae0a7808fa19f3320164-icon"
          alt=""
          src="/3569caa8c429ae0a7808fa19f3320164@2x.png"
        />
      </div>
      <div className="welcome-page-item" />
      <b className="page-1">Page 1</b>
      <b className="page-2">Page 2</b>
      <b className="page-3">Page 3</b>
      <div className="welcome-page-inner" />
      <div className="write-anything">write anything...</div>
      <div className="welcome-page-child1" />
      <b className="send">SEND</b>
      <img className="send-fill-icon" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor8">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor9">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor10">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="welcome-page-child2" />
      <div className="logo1">Logo</div>
    </div>
  );
};

export default WelcomePage;
