import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./AvailableCampaigns.css";

const AvailableCampaigns = () => {
  const navigate = useNavigate();

  const onWishlist11Click = useCallback(() => {
    navigate("/saving");
  }, [navigate]);

  const onWishlist13Click = useCallback(() => {
    navigate("/saving");
  }, [navigate]);

  const onMaskGroupImage9Click = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  const onBellIconClick = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  const onEllipse12Click = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  return (
    <div className="available-campaigns">
      <div className="available-campaigns-child" />
      <div className="available-campaigns-item" />
      <div className="available-campaigns-inner" />
      <div className="available-campaigns-child1" />
      <div className="available-campaigns-child2" />
      <div className="available-campaigns-child3" />
      <div className="available-campaigns-child4" />
      <div className="available-campaigns-child5" />
      <div className="available-campaigns-child6" />
      <b className="page-16">Page 1</b>
      <b className="page-26">Page 2</b>
      <b className="page-36">Page 3</b>
      <div className="available-campaigns-child7" />
      <div className="write-anything10">write anything...</div>
      <div className="available-campaigns-child8" />
      <b className="send10">SEND</b>
      <img className="send-fill-icon9" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor26">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor27">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor28">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="available-campaigns-child9" />
      <div className="logo18">Logo</div>
      <div className="available-campaigns1">Available Campaigns</div>
      <div className="available-campaigns-child10" />
      <div className="search6">Search</div>
      <div className="available-campaigns-child11" />
      <img className="filter-big-icon" alt="" src="/filter-big.svg" />
      <div className="available-campaigns-child12" />
      <div className="available-campaigns-child13" />
      <div className="available-campaigns-child14" />
      <div className="available-campaigns-child15" />
      <div className="available-campaigns-child16" />
      <div className="available-campaigns-child17" />
      <div className="available-campaigns-child18" />
      <div className="available-campaigns-child19" />
      <div className="available-campaigns-child20" />
      <div className="available-campaigns-child21" />
      <div className="consult">Consult</div>
      <div className="consult1">Consult</div>
      <div className="make-up-campaign">Make Up Campaign</div>
      <div className="filter-par">Filter par</div>
      <div className="headphone-campaign">Headphone Campaign</div>
      <div className="accessories-campaign">Accessories Campaign</div>
      <img className="mask-group-icon24" alt="" src="/mask-group@2x.png" />
      <div className="available-campaigns-child22" />
      <div className="lorem-ipsum-dolor29">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nnumm
      </div>
      <div className="lorem-ipsum-dolor30">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor31">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="available-campaigns-child23" />
      <div className="available-campaigns-child24" />
      <div className="available-campaigns-child25" />
      <div className="consult2">Consult</div>
      <div className="consult3">Consult</div>
      <div className="consult4">Consult</div>
      <div className="available-campaigns-child26" />
      <div className="consult5">Consult</div>
      <div className="available-campaigns-child27" />
      <div className="consult6">Consult</div>
      <div className="available-campaigns-child28" />
      <div className="consult7">Consult</div>
      <div className="consult8">Consult</div>
      <div className="available-campaigns-child29" />
      <div className="consult9">Consult</div>
      <div className="fashion-campaign">Fashion Campaign</div>
      <div className="black-friday-campaign">Black Friday Campaign</div>
      <div className="sportswear-campaign">Sportswear Campaign</div>
      <div className="spiring-sale-campaign">Spiring Sale Campaign</div>
      <div className="decoration-campaign">Decoration Campaign</div>
      <div className="shoes-campaign">Shoes Campaign</div>
      <div className="lorem-ipsum-dolor32">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor33">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor34">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor35">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor36">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="lorem-ipsum-dolor37">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon25" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon26" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon27" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon28" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon29" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon30" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon31" alt="" src="/mask-group@2x.png" />
      <img className="mask-group-icon32" alt="" src="/mask-group@2x.png" />
      <div className="available-campaigns-child30" />
      <div className="available-campaigns-child31" />
      <div className="available-campaigns-child32" />
      <img
        className="wishlist-1-1"
        alt=""
        src="/wishlist-1-1@2x.png"
        onClick={onWishlist11Click}
      />
      <img className="wishlist-1-2" alt="" src="/wishlist-1-1@2x.png" />
      <img
        className="wishlist-1-3"
        alt=""
        src="/wishlist-1-1@2x.png"
        onClick={onWishlist13Click}
      />
      <div className="available-campaigns-child33" />
      <div className="available-campaigns-child34" />
      <div className="available-campaigns-child35" />
      <img className="wishlist-1-4" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-5" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-6" alt="" src="/wishlist-1-1@2x.png" />
      <div className="available-campaigns-child36" />
      <div className="available-campaigns-child37" />
      <div className="available-campaigns-child38" />
      <img className="wishlist-1-7" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-8" alt="" src="/wishlist-1-1@2x.png" />
      <img className="wishlist-1-9" alt="" src="/wishlist-1-1@2x.png" />
      <img
        className="expand-down-light-icon5"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="available-campaigns-child39" />
      <div className="available-campaigns-child40" />
      <div className="logo19">Logo</div>
      <div className="available-campaigns-child41" />
      <div className="search7">Search</div>
      <img className="group-icon6" alt="" src="/group2.svg" />
      <img className="group-icon7" alt="" src="/group2.svg" />
      <img
        className="mask-group-icon33"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImage9Click}
      />
      <div className="sarah-masmoudi5">Sarah Masmoudi</div>
      <div className="influenceur4">Influenceur</div>
      <img
        className="bell-icon4"
        alt=""
        src="/bell.svg"
        onClick={onBellIconClick}
      />
      <img className="wishlist-1-104" alt="" src="/wishlist-1-10@2x.png" />
      <img className="farasha-02-1-icon3" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns">
        <p className="my-campaigns1">My campaigns</p>
        <p className="my-campaigns1">{` `}</p>
      </div>
      <div className="available-campaigns-child42" />
      <img className="home-icon2" alt="" src="/home1.svg" />
      <div className="my-space2">My Space</div>
      <div className="collaborations2" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <img className="partnership-1-icon2" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard5" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile3" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard2">
        <div className="darhboard-child6" />
        <div className="darhboard-child7" />
        <div className="darhboard-child8" />
        <div className="darhboard-child9" />
      </div>
      <img className="user-alt-icon2" alt="" src="/user-alt1.svg" />
      <div className="available-campaigns-child43" onClick={onEllipse12Click} />
    </div>
  );
};

export default AvailableCampaigns;
