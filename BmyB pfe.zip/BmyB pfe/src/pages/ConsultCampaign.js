import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ConsultCampaign.css";

const ConsultCampaign = () => {
  const navigate = useNavigate();

  const onMaskGroupImageClick = useCallback(() => {
    navigate("/log-out");
  }, [navigate]);

  const onBellIconClick = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  const onWishlist110Click = useCallback(() => {
    navigate("/wish-list");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onDashboardTextClick = useCallback(() => {
    navigate("/dashboard");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  const onEllipse3Click = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  return (
    <div className="consult-campaign">
      <div className="consult-campaign-child" />
      <div className="consult-campaign-item" />
      <div className="consult-campaign-inner" />
      <div className="consult-campaign-child1" />
      <div className="consult-campaign-child2" />
      <div className="consult-campaign-child3" />
      <div className="consult-campaign-child4" />
      <div className="consult-campaign-child5" />
      <div className="consult-campaign-child6" />
      <b className="page-110">Page 1</b>
      <b className="page-210">Page 2</b>
      <b className="page-310">Page 3</b>
      <div className="consult-campaign-child7" />
      <div className="write-anything14">write anything...</div>
      <div className="consult-campaign-child8" />
      <b className="send14">SEND</b>
      <img className="send-fill-icon13" alt="" src="/send-fill@2x.png" />
      <div className="lorem-ipsum-dolor74">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor75">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="lorem-ipsum-dolor76">{`Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim `}</div>
      <div className="consult-campaign-child9" />
      <div className="logo26">Logo</div>
      <img
        className="expand-down-light-icon9"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="consult-campaign-child10" />
      <div className="consult-campaign-child11" />
      <div className="logo27">Logo</div>
      <div className="consult-campaign-child12" />
      <div className="search14">Search</div>
      <img className="group-icon14" alt="" src="/group2.svg" />
      <img
        className="mask-group-icon65"
        alt=""
        src="/mask-group@2x.png"
        onClick={onMaskGroupImageClick}
      />
      <div className="sarah-masmoudi10">Sarah Masmoudi</div>
      <div className="influenceur8">Influenceur</div>
      <img
        className="bell-icon8"
        alt=""
        src="/bell.svg"
        onClick={onBellIconClick}
      />
      <img
        className="wishlist-1-108"
        alt=""
        src="/wishlist-1-10@2x.png"
        onClick={onWishlist110Click}
      />
      <img className="farasha-02-1-icon7" alt="" src="/farasha02-1@2x.png" />
      <div className="my-campaigns8">
        <p className="my-campaigns9">My campaigns</p>
        <p className="my-campaigns9">{` `}</p>
      </div>
      <div className="consult-campaign-child13" />
      <img className="separator-icon" alt="" src="/separator.svg" />
      <img className="separator-icon1" alt="" src="/separator1.svg" />
      <div className="separator" />
      <img className="home-icon6" alt="" src="/home1.svg" />
      <div className="my-space6">My Space</div>
      <div className="collaborations6" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <img className="partnership-1-icon6" alt="" src="/partnership-1@2x.png" />
      <div className="dashboard9" onClick={onDashboardTextClick}>
        Dashboard
      </div>
      <div className="my-profile7" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard6">
        <div className="darhboard-child22" />
        <div className="darhboard-child23" />
        <div className="darhboard-child24" />
        <div className="darhboard-child25" />
      </div>
      <img className="user-alt-icon6" alt="" src="/user-alt1.svg" />
      <b className="fashion-campaign4">Fashion Campaign</b>
      <div className="description">Description</div>
      <div className="page-link">Page link</div>
      <div className="ethereal-elegance-encapsulate">
        "Ethereal Elegance" encapsulates the essence of timeless beauty and
        sophistication, transporting the audience into a world where grace meets
        modernity. This campaign celebrates the fusion of ethereal elements with
        contemporary style, presenting a collection that exudes refinement and
        allure.
      </div>
      <div className="consult-campaign-child14" />
      <div className="products">Products</div>
      <div className="httpslinkco">https:/Link.co</div>
      <div className="consult-campaign-child15" />
      <div className="consult-campaign-child16" />
      <div className="consulter">Consulter</div>
      <div className="nom-du-produit">Nom du produit</div>
      <div className="lorem-ipsum-dolor77">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="consult-campaign-child17" />
      <div className="consult-campaign-child18" />
      <div className="consulter1">Consulter</div>
      <div className="nom-du-produit1">Nom du produit</div>
      <div className="lorem-ipsum-dolor78">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <div className="consult-campaign-child19" />
      <div className="consult-campaign-child20" />
      <div className="consult-campaign-child21" />
      <div className="consulter2">Consulter</div>
      <div className="nom-du-produit2">Nom du produit</div>
      <div className="lorem-ipsum-dolor79">
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
        nonumm
      </div>
      <img className="mask-group-icon66" alt="" src="/mask-group@2x.png" />
      <img className="r-2-icon" alt="" src="/r-2@2x.png" />
      <img className="oip-2-icon" alt="" src="/oip-2@2x.png" />
      <img
        className="l1421-red3-1000x1000-1"
        alt=""
        src="/l1421-red31000x1000-1@2x.png"
      />
      <div className="conditions-of-collaboration">
        Conditions of collaboration
      </div>
      <div className="the-influencer-agrees">
        The influencer agrees to submit a detailed outline for approval before
        creating a blog post featuring the 'Ethereal Elegance' collection,
        ensuring accurate representation of the brand's values and product
        features. The post must adhere to a mutually agreed-upon timeline and
        comply with disclosure regulations, prominently featuring the products
        and optimizing content for SEO. During a specified exclusivity period,
        the influencer will refrain from promoting competing brands or similar
        products, while the business manager reserves the right to track
        performance metrics and usage rights. Compensation terms are agreed upon
        in advance, encompassing monetary payment, gifted products, or other
        forms of remuneration, while both parties collaborate to achieve
        marketing objectives and maximize the impact of the collaboration
      </div>
      <div className="consult-campaign-child22" />
      <div className="participate">Participate</div>
      <div className="consult-campaign-child23" onClick={onEllipse3Click} />
    </div>
  );
};

export default ConsultCampaign;
