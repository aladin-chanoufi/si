import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./SignIn.css";

const SignIn = () => {
  const navigate = useNavigate();

  const onSignInTextClick = useCallback(() => {
    navigate("/comp-personal-info-inf");
  }, [navigate]);

  const onForgotYourPasswordClick = useCallback(() => {
    navigate("/forgot-password");
  }, [navigate]);

  return (
    <div className="sign-in2">
      <div className="sign-in-child" />
      <img className="icon3" alt="" src="/33-787@2x.png" />
      <div className="your-next-collaboration-container1">
        <p className="your-next-collaboration1">
          <span className="your-next1">{`Your next `}</span>
          <b>{`COLLABORATION `}</b>
        </p>
        <p className="adventure-awaits1">adventure awaits</p>
      </div>
      <div className="welcome-back1">Welcome Back !</div>
      <img className="frame-icon4" alt="" src="/frame.svg" />
      <img className="frame-icon5" alt="" src="/frame1.svg" />
      <div className="sign-in-item" />
      <div className="sign-in-inner" />
      <div className="logo4">LOGO</div>
      <div className="sign-in-child1" />
      <div className="sign-in3" onClick={onSignInTextClick}>
        Sign In
      </div>
      <div className="sign-in-child2" />
      <div className="sign-in-child3" />
      <div className="sign-in-child4" />
      <div className="sign-in-child4" />
      <div className="sign-in-child6" />
      <div className="sign-in-child7" />
      <div className="sign-in-to1">Sign In to BmyB</div>
      <img className="tiktok-icon2" alt="" src="/tiktok@2x.png" />
      <img className="google-icon2" alt="" src="/google@2x.png" />
      <img className="fb-icon2" alt="" src="/fb@2x.png" />
      <img className="inst-icon2" alt="" src="/inst@2x.png" />
      <div className="sign-in-child8" />
      <img className="view-hide-icon3" alt="" src="/view-hide@2x.png" />
      <div className="full-name24">
        <div className="full-name25">Influencer</div>
      </div>
      <div className="full-name26">
        <div className="full-name25">Business owner</div>
      </div>
      <div className="sign-in-child9" />
      <div className="sign-in-child10" />
      <div className="sign-in-child11" />
      <img
        className="pretty-girl-pink-striped-pants-icon1"
        alt=""
        src="/prettygirlpinkstripedpantsposingindoorshotspectaculareuropeanwomanfurcoatfoolingaroundpurplewallremovebgpreview-1@2x.png"
      />
      <div className="forgot-your-password" onClick={onForgotYourPasswordClick}>
        Forgot your password ?
      </div>
      <div className="dont-ave-an">{`Don’t ave an account ? `}</div>
      <div className="sign-up2">Sign Up</div>
      <div className="full-name28">
        <div className="full-name29">Masmoudi.sarra@gmail.com</div>
      </div>
      <div className="full-name30">
        <div className="full-name25">Email</div>
      </div>
      <div className="full-name32">
        <div className="full-name25">**********</div>
      </div>
      <div className="full-name34">
        <div className="full-name25">Password</div>
      </div>
    </div>
  );
};

export default SignIn;
