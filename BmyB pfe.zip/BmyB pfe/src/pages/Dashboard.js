import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();

  const onWishlist110Click = useCallback(() => {
    navigate("/wish-list");
  }, [navigate]);

  const onMySpaceTextClick = useCallback(() => {
    navigate("/saving");
  }, [navigate]);

  const onCollaborationsTextClick = useCallback(() => {
    navigate("/influencer-collaboration");
  }, [navigate]);

  const onMyProfileTextClick = useCallback(() => {
    navigate("/-profile-influenceur");
  }, [navigate]);

  const onEllipse2Click = useCallback(() => {
    navigate("/notification");
  }, [navigate]);

  return (
    <div className="dashboard1">
      <div className="dashboard-child" />
      <b className="dashboard2">
        <p className="dashboard3">Dashboard</p>
      </b>
      <div className="dashboard-item" />
      <div className="dashboard-inner" />
      <div className="transactions">Transactions</div>
      <b className="sales">233 Sales</b>
      <div className="campaigns">Campaigns</div>
      <b className="b">20</b>
      <div className="dashboard-child1" />
      <div className="engagement">Engagement</div>
      <img
        className="expand-down-light-icon3"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="revenus">Revenus</div>
      <b className="dt">10.000 dt</b>
      <div className="dashboard-child2" />
      <div className="dashboard-child3" />
      <img
        className="expand-down-light-icon3"
        alt=""
        src="/expand-down-light.svg"
      />
      <div className="dashboard-child4" />
      <div className="dashboard-child5" />
      <div className="logo17">Logo</div>
      <div className="dashboard-child6" />
      <div className="search5">Search</div>
      <img className="group-icon5" alt="" src="/group2.svg" />
      <img className="mask-group-icon23" alt="" src="/mask-group@2x.png" />
      <div className="sarah-masmoudi4">Sarah Masmoudi</div>
      <div className="influenceur3">Influenceur</div>
      <img className="bell-icon3" alt="" src="/bell.svg" />
      <img
        className="wishlist-1-103"
        alt=""
        src="/wishlist-1-10@2x.png"
        onClick={onWishlist110Click}
      />
      <img className="farasha-02-1-icon2" alt="" src="/farasha02-1@2x.png" />
      <div className="dashboard-child7" />
      <img className="partnership-1-icon1" alt="" src="/partnership-1@2x.png" />
      <img className="home-icon1" alt="" src="/home.svg" />
      <div className="my-space1" onClick={onMySpaceTextClick}>
        My Space
      </div>
      <div className="collaborations1" onClick={onCollaborationsTextClick}>
        Collaborations
      </div>
      <div className="dashboard4">Dashboard</div>
      <div className="my-profile2" onClick={onMyProfileTextClick}>
        My Profile
      </div>
      <div className="darhboard1">
        <div className="darhboard-child2" />
        <div className="darhboard-child3" />
        <div className="darhboard-child4" />
        <div className="darhboard-child5" />
      </div>
      <img className="user-alt-icon1" alt="" src="/user-alt1.svg" />
      <div className="order-time">
        <div className="afternoon">
          <div className="afternoon-child" />
          <div className="afternoon1">Afternoon</div>
          <div className="div4">40%</div>
        </div>
        <div className="evening">
          <div className="evening-child" />
          <div className="evening1">Evening</div>
          <div className="div4">32%</div>
        </div>
        <div className="morning">
          <div className="morning-child" />
          <div className="evening1">Morning</div>
          <div className="div4">28%</div>
        </div>
        <img className="chart-icon" alt="" src="/chart.svg" />
        <div className="button">
          <img className="button-child" alt="" src="/rectangle-25.svg" />
          <div className="view-report">View Report</div>
        </div>
        <div className="order-info">From 1-6 Dec, 2020</div>
        <div className="title-data">Order Time</div>
      </div>
      <div className="order-stats">
        <div className="line-parent">
          <img className="line-icon1" alt="" src="/line.svg" />
          <img className="line-icon2" alt="" src="/line.svg" />
          <img className="line-icon3" alt="" src="/line.svg" />
          <img className="line-icon4" alt="" src="/line1.svg" />
          <div className="div7">01</div>
          <div className="div8">02</div>
          <div className="div9">03</div>
          <div className="div10">04</div>
          <div className="div11">05</div>
          <div className="div12">06</div>
        </div>
        <div className="button">
          <img className="button-child" alt="" src="/rectangle-25.svg" />
          <div className="view-report">View Report</div>
        </div>
        <div className="title-data1">Revenus</div>
        <div className="number">2.568</div>
        <div className="info">
          <div className="vs-last-7-container">
            <span className="span4">2.1%</span>
            <span className="vs-last-week"> vs last week</span>
          </div>
          <img className="arrow-down-icon" alt="" src="/arrow-down@2x.png" />
        </div>
        <div className="graphic-design">Sales from 1-6 Dec, 2020</div>
        <div className="ellipse-parent">
          <div className="group-child" />
          <div className="last-6-days">Last 6 days</div>
        </div>
        <div className="ellipse-group">
          <div className="group-item" />
          <div className="last-6-days">Last Week</div>
        </div>
        <img className="order-stats-child" alt="" src="/line-35.svg" />
        <img className="order-stats-item" alt="" src="/line-34.svg" />
      </div>
      <div className="revenue">
        <div className="chart">
          <img className="chart-child" alt="" src="/line-4.svg" />
          <img className="chart-item" alt="" src="/line-4.svg" />
          <img className="chart-inner" alt="" src="/line-4.svg" />
          <img className="chart-child1" alt="" src="/line-6.svg" />
          <div className="parent">
            <div className="div13">01</div>
            <img className="group-inner" alt="" src="/rectangle-6.svg" />
            <img className="rectangle-icon" alt="" src="/rectangle-7.svg" />
          </div>
          <div className="group">
            <div className="div14">07</div>
            <img className="group-inner" alt="" src="/rectangle-6.svg" />
            <img className="rectangle-icon" alt="" src="/rectangle-7.svg" />
          </div>
          <div className="container">
            <div className="div14">02</div>
            <img className="group-child3" alt="" src="/rectangle-61.svg" />
            <img className="group-child4" alt="" src="/rectangle-71.svg" />
          </div>
          <div className="group-div">
            <div className="div14">08</div>
            <img className="group-child3" alt="" src="/rectangle-61.svg" />
            <img className="group-child4" alt="" src="/rectangle-71.svg" />
          </div>
          <div className="parent1">
            <div className="div17">03</div>
            <img className="group-child7" alt="" src="/rectangle-62.svg" />
            <img className="group-child8" alt="" src="/rectangle-72.svg" />
          </div>
          <div className="parent2">
            <div className="div17">09</div>
            <img className="group-child7" alt="" src="/rectangle-62.svg" />
            <img className="group-child8" alt="" src="/rectangle-72.svg" />
          </div>
          <div className="parent3">
            <div className="div17">04</div>
            <img className="group-child11" alt="" src="/rectangle-63.svg" />
            <img className="group-child12" alt="" src="/rectangle-73.svg" />
          </div>
          <div className="parent4">
            <div className="div20">10</div>
            <img className="group-child11" alt="" src="/rectangle-63.svg" />
            <img className="group-child12" alt="" src="/rectangle-73.svg" />
          </div>
          <div className="parent5">
            <div className="div21">05</div>
            <img className="group-child15" alt="" src="/rectangle-64.svg" />
            <img className="group-child16" alt="" src="/rectangle-74.svg" />
          </div>
          <div className="parent6">
            <div className="div22">11</div>
            <img className="group-child15" alt="" src="/rectangle-64.svg" />
            <img className="group-child16" alt="" src="/rectangle-74.svg" />
          </div>
          <div className="parent7">
            <div className="div23">06</div>
            <img className="group-child19" alt="" src="/rectangle-65.svg" />
            <img className="group-child20" alt="" src="/rectangle-7.svg" />
          </div>
          <div className="parent8">
            <div className="div24">12</div>
            <img className="group-child19" alt="" src="/rectangle-65.svg" />
            <img className="group-child20" alt="" src="/rectangle-7.svg" />
          </div>
        </div>
        <div className="button2">
          <img className="button-child" alt="" src="/rectangle-25.svg" />
          <div className="view-report">View Report</div>
        </div>
        <div className="title-data2">Sales</div>
        <div className="amount">IDR 7.852.000</div>
        <div className="percentage-info">
          <div className="vs-last-7-container">
            <span className="span4">2.1%</span>
            <span className="vs-last-week"> vs last week</span>
          </div>
          <img className="arrow-up-icon" alt="" src="/arrow-up.svg" />
        </div>
        <div className="sales-info">Sales from 1-12 Dec, 2020</div>
        <div className="last-6-days1">
          <div className="last-6-days-child" />
          <div className="last-6-days">Last week</div>
        </div>
        <div className="last-week2">
          <div className="last-week-child" />
          <div className="last-6-days">Last month</div>
        </div>
      </div>
      <div className="dashboard-child8" onClick={onEllipse2Click} />
    </div>
  );
};

export default Dashboard;
