import "./RestLink.css";

const RestLink = () => {
  return (
    <div className="rest-link">
      <div className="rest-link-child" />
      <img className="icon5" alt="" src="/33-787@2x.png" />
      <div className="rest-link-item" />
      <div className="logo6">LOGO</div>
      <div className="rest-link-inner" />
      <div className="forgot-password2">Forgot password</div>
      <div className="please-select-your1">
        Please select your option to send password reset link
      </div>
      <div className="rest-link-child1" />
      <img className="check-fill-icon" alt="" src="/check-fill@2x.png" />
      <div className="the-reset-link2">
        The reset link will be sent to your email adress registered
      </div>
      <div className="rest-link-child2" />
      <div className="message1">
        <div className="message-inner" />
        <img className="vector-icon" alt="" src="/vector-31.svg" />
      </div>
      <div className="reset-via-email1">Reset via email</div>
      <div className="rest-link-child3" />
      <img className="phone-icon1" alt="" />
      <div className="rest-link-child4" />
      <div className="reset-via-sms1">Reset via SMS</div>
      <div className="the-reset-link3">
        The reset link will be sent to your phone number registered
      </div>
      <img className="telephone-1-icon1" alt="" src="/telephone-1@2x.png" />
    </div>
  );
};

export default RestLink;
