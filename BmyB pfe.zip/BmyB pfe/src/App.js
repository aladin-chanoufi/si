import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import WelcomePage from "./pages/WelcomePage";
import SignUp from "./pages/SignUp";
import WrongPass from "./pages/WrongPass";
import SignIn from "./pages/SignIn";
import ForgotPassword from "./pages/ForgotPassword";
import RestLink from "./pages/RestLink";
import CampaignCategories from "./pages/CampaignCategories";
import PickedAtegories from "./pages/PickedAtegories";
import ProfileInfluenceur from "./pages/ProfileInfluenceur";
import CompPersonalInfoInf from "./pages/CompPersonalInfoInf";
import CompFinancialInfoInf from "./pages/CompFinancialInfoInf";
import Dashboard from "./pages/Dashboard";
import AvailableCampaigns from "./pages/AvailableCampaigns";
import Notification1 from "./pages/Notification1";
import LogOut from "./pages/LogOut";
import Saving from "./pages/Saving";
import ConsultCampaign from "./pages/ConsultCampaign";
import InfluencerCollaboration from "./pages/InfluencerCollaboration";
import WishList from "./pages/WishList";
import DeleteFromWishList from "./pages/DeleteFromWishList";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up":
        title = "";
        metaDescription = "";
        break;
      case "/wrong-pass":
        title = "";
        metaDescription = "";
        break;
      case "/sign-in":
        title = "";
        metaDescription = "";
        break;
      case "/forgot-password":
        title = "";
        metaDescription = "";
        break;
      case "/rest-link":
        title = "";
        metaDescription = "";
        break;
      case "/campaign-categories":
        title = "";
        metaDescription = "";
        break;
      case "/picked-ategories":
        title = "";
        metaDescription = "";
        break;
      case "/-profile-influenceur":
        title = "";
        metaDescription = "";
        break;
      case "/comp-personal-info-inf":
        title = "";
        metaDescription = "";
        break;
      case "/comp-financial-info-inf":
        title = "";
        metaDescription = "";
        break;
      case "/dashboard":
        title = "";
        metaDescription = "";
        break;
      case "/available-campaigns":
        title = "";
        metaDescription = "";
        break;
      case "/notification":
        title = "";
        metaDescription = "";
        break;
      case "/log-out":
        title = "";
        metaDescription = "";
        break;
      case "/saving":
        title = "";
        metaDescription = "";
        break;
      case "/consult-campaign":
        title = "";
        metaDescription = "";
        break;
      case "/influencer-collaboration":
        title = "";
        metaDescription = "";
        break;
      case "/wish-list":
        title = "";
        metaDescription = "";
        break;
      case "/delete-from-wish-list":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<WelcomePage />} />
      <Route path="/sign-up" element={<SignUp />} />
      <Route path="/wrong-pass" element={<WrongPass />} />
      <Route path="/sign-in" element={<SignIn />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/rest-link" element={<RestLink />} />
      <Route path="/campaign-categories" element={<CampaignCategories />} />
      <Route path="/picked-ategories" element={<PickedAtegories />} />
      <Route path="/-profile-influenceur" element={<ProfileInfluenceur />} />
      <Route path="/comp-personal-info-inf" element={<CompPersonalInfoInf />} />
      <Route
        path="/comp-financial-info-inf"
        element={<CompFinancialInfoInf />}
      />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/available-campaigns" element={<AvailableCampaigns />} />
      <Route path="/notification" element={<Notification1 />} />
      <Route path="/log-out" element={<LogOut />} />
      <Route path="/saving" element={<Saving />} />
      <Route path="/consult-campaign" element={<ConsultCampaign />} />
      <Route
        path="/influencer-collaboration"
        element={<InfluencerCollaboration />}
      />
      <Route path="/wish-list" element={<WishList />} />
      <Route path="/delete-from-wish-list" element={<DeleteFromWishList />} />
    </Routes>
  );
}
export default App;
